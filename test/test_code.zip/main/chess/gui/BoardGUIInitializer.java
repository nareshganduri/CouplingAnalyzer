package chess.gui;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import chess.game.Game;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

/**
 * A helper class to set up the GUI of the board manager
 * 
 * @author Naresh Ganduri
 *
 */
public class BoardGUIInitializer {
    private Text bottomCaption;

    /**
     * Initializes the title, the board, and the bottom captions
     */
    public void initializeGUI() {
        // start up the game
        Game.initializeGame();

        BoardGUIManager.mainPane = new BorderPane();

        createTitle();
        createTiles();
        createBottomCaption();
    }

    /**
     * Creates the title at the top of the screen and adds a menu bar
     * 
     * @param mainPane
     *            the Pane to add the title to
     */
    private void createTitle() {
        HBox titleHBox = new HBox();

        MenuBar menubar = new MenuBar();
        Menu menuFile = new Menu("File");
        MenuItem undoItem = buildMenuItem("Undo", "handleUndo");
        MenuItem forfeitItem = buildMenuItem("Forfeit", "handleForfeit");
        MenuItem restartItem = buildMenuItem("Restart", "handleRestart");
        MenuItem scoreItem = buildMenuItem("View Score", "viewScore");
        
        Menu optionsFile = new Menu("Options");
        MenuItem toggleCustomsItem = buildMenuItem("Toggle Custom Pieces", "toggleCustoms");

        menuFile.getItems().addAll(undoItem, forfeitItem, restartItem, scoreItem);
        optionsFile.getItems().addAll(toggleCustomsItem);
        menubar.getMenus().addAll(menuFile, optionsFile);

        titleHBox.getChildren().addAll(menubar);
        BoardGUIManager.mainPane.setTop(titleHBox);
    }

    /**
     * Helper function for creating menu items and binding event handlers to them
     * 
     * @param itemText
     *            the text displayed on the menu item
     * @param handlerName
     *            a String representing the name of the event handler to invoke
     * @return the new MenuItem
     */
    private MenuItem buildMenuItem(String itemText, String handlerName) {
        try {
            Method handlerMethod = BoardGUIManager.class.getMethod(handlerName);
            MenuItem newItem = new MenuItem(itemText);
            newItem.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent a) {
                    try {
                        handlerMethod.invoke(null);
                    } catch (IllegalAccessException ignore) {
                        // ignore
                    } catch (IllegalArgumentException ignore) {
                        // ignore
                    } catch (InvocationTargetException ignore) {
                        // ignore
                    }
                }
            });
            return newItem;
        } catch (NoSuchMethodException ignore) {
            // ignore
        } catch (SecurityException ignore) {
            // Ignore
        }
        return null;
    }

    /**
     * Creates the TileButtons that represent user interactive tiles on the game
     * board and sets them up correctly, storing them in a 2d array to keep track of
     * them
     * 
     * @param mainPane
     *            the Pane to add the tiles to
     */
    private void createTiles() {
        // put the board in the center of the window as a GridPane
        BoardGUIManager.tiles = new TileButton[Game.BOARD_WIDTH][Game.BOARD_HEIGHT];
        GridPane boardPane = new GridPane();
        for (int i = 0; i < Game.BOARD_WIDTH; i++) {
            for (int j = 0; j < Game.BOARD_HEIGHT; j++) {
                TileButton tileButton = new TileButton(i, j);
                GridPane.setRowIndex(tileButton, Game.BOARD_WIDTH - j);
                GridPane.setColumnIndex(tileButton, i);

                // add children to boardPane
                BoardGUIManager.tiles[i][j] = tileButton;
                boardPane.getChildren().addAll(tileButton);
            }
        }
        BoardGUIManager.mainPane.setCenter(boardPane);
    }

    /**
     * Creates the caption at the bottom of the screen
     */
    private void createBottomCaption() {
        // create an HBox saying whose turn it is
        HBox bottomHBox = new HBox();
        bottomCaption = new Text("White Player's Turn");
        bottomHBox.getChildren().addAll(bottomCaption);
        BoardGUIManager.mainPane.setBottom(bottomHBox);
    }
}
