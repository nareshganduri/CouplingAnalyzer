package chess.gui;

import java.util.ArrayList;
import java.util.Optional;

import chess.game.Game;
import chess.game.layout.Move;
import chess.game.layout.OutOfBoundsException;
import chess.game.layout.Spot;
import chess.game.pieces.Piece;
import chess.game.ui.MoveItem;
import chess.game.utils.MoveList;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

/**
 * The BoardGUIManager class manages the game board GUI
 * 
 * @author Naresh Ganduri
 *
 */
public class BoardGUIManager {
    static Text bottomCaption;
    static TileButton[][] tiles;
    static BorderPane mainPane;

    static TileButton selectedTile = null;

    /**
     * Returns the TileButton at the given spot
     * 
     * @param xPos
     *            the x position of the TileButton
     * @param yPos
     *            the y position of the TileButton
     * @return the TileButton at index [xPos][yPos]
     */
    public static TileButton getTile(int xPos, int yPos) {
        return tiles[xPos][yPos];
    }

    /**
     * Highlights all the tiles that a piece can move to on the board
     * 
     * @param tileButton
     *            the TileButton that was clicked on
     */
    public static void highlightPossibles(TileButton tileButton) {
        selectedTile = tileButton;
        Spot spot = tileButton.getCorrespondingSpot();
        Piece occupant = spot.getOccupant();
        Game.selectedPiece = occupant;
        MoveList validMoves = occupant.computeValidMoves();

        for (int i = 0; i < validMoves.size(); i++) {
            Move currMove = validMoves.get(i);

            try {
                Spot newSpot = spot.addMove(currMove);

                TileButton possibleTile = getTile(newSpot.getXPos(), newSpot.getYPos());
                possibleTile.setHighlight();
                possibleTile.setIsPossibleMove(true);
            } catch (OutOfBoundsException ignore) {
                // ignore
            }
        }
    }

    /**
     * Resets the TileButton colors if the user deselects their piece
     */
    public static void resetBGColor() {
        Game.selectedPiece = null;
        selectedTile = null;
        for (int i = 0; i < Game.BOARD_WIDTH; i++) {
            for (int j = 0; j < Game.BOARD_HEIGHT; j++) {
                getTile(i, j).setImage();
                getTile(i, j).setBGColor();
                getTile(i, j).setIsPossibleMove(false);
                getTile(i, j).setIsSelected(false);
            }
        }
    }

    /**
     * Updates the caption at the bottom of the window
     */
    public static void updateCaption() {
        // create an HBox saying whose turn it is
        HBox bottomHBox = new HBox();
        String playerString = Game.getPlayerToMove().getPlayerString();
        String captionString;
        boolean checkmate = false;

        if (Game.getPlayerToMove().getKing().isInCheckmate()) {
            captionString = playerString + " Player in checkmate!";
            checkmate = true;
        } else if (Game.getPlayerToMove().getKing().isInCheck()) {
            captionString = playerString + " Player in check!";
        } else {
            captionString = playerString + " Player's turn";
        }

        bottomCaption = new Text(captionString);
        bottomHBox.getChildren().addAll(bottomCaption);
        mainPane.setBottom(bottomHBox);

        if (checkmate) {
            handleCheckmate();
        }
    }

    /**
     * Handles what to do if there is a checkmate
     */
    public static void handleCheckmate() {
        String message = "There was a checkmate!\n\nWould you like to start a new game?";
        Alert checkmateConfirm = new Alert(AlertType.INFORMATION, message);
        Optional<ButtonType> result = checkmateConfirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            MainWindow.getScoreManager().updateScores();
            startNewGame();
        }
    }

    /**
     * Handles what to do if the player chooses undo
     */
    public static void handleUndo() {
        ArrayList<MoveItem> moveStack = Game.getMoveStack();
        if (moveStack.size() == 0) {
            Alert noUndoError = new Alert(AlertType.ERROR, "No more moves to undo!");
            noUndoError.showAndWait();
        } else {
            Game.undoLastMove();

            resetBGColor();
            updateCaption();
        }
    }

    /**
     * Handles what to do if a player wants to restart
     */
    public static void handleRestart() {
        String playerString = Game.getPlayerToMove().getPlayerString();
        String message = "The " + playerString + " player would like to restart this game. "
                + "\n\nWill you accept the restart?";
        Alert restartConfirm = new Alert(AlertType.CONFIRMATION, message);

        Optional<ButtonType> result = restartConfirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            startNewGame();
        }
    }

    /**
     * Event handler for forfeit events
     */
    public static void handleForfeit() {
        String playerString = Game.getPlayerToMove().getPlayerString();
        String message = "The " + playerString + " Player has forfeit!";
        Alert forfeitInfo = new Alert(AlertType.INFORMATION, message);
        forfeitInfo.showAndWait();

        startNewGame();
    }

    /**
     * Event handler for seeing the game score
     */
    public static void viewScore() {
        int whiteScore = MainWindow.getScoreManager().getWhiteScore();
        int blackScore = MainWindow.getScoreManager().getBlackScore();
        String scoreString = "White: " + whiteScore + "\nBlack: " + blackScore;

        Alert scoreInfo = new Alert(AlertType.INFORMATION, scoreString);
        scoreInfo.showAndWait();
    }

    /**
     * Toggles whether the custom pieces should be used in the game
     */
    public static void toggleCustoms() {
        String confirmString = "Are you sure you want to toggle the custom pieces?"
                + "\n\nThis option will reset the game board, and your current game will be lost!";

        Alert toggleConfirm = new Alert(AlertType.CONFIRMATION, confirmString);
        Optional<ButtonType> result = toggleConfirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            boolean isUsingCustomPieces = Game.getUsingCustomPieces();
            Game.setIsUsingCustomPieces(!isUsingCustomPieces);
            startNewGame();
        }
    }

    /**
     * Helper function to start a new game
     */
    static void startNewGame() {
        BoardGUIInitializer boardInitializer = new BoardGUIInitializer();
        boardInitializer.initializeGUI();
        MainWindow.initializeWindow(mainPane);
    }

    /**
     * Helper function for actually moving the pieces on tiles
     * 
     * @param tileButton
     *            the tile corresponding to the destination spot for the selected
     *            piece
     */
    public static void handleMove(TileButton tileButton) {
        Game.makeNewMove(tileButton.getCorrespondingSpot());
        
        resetBGColor();
        updateCaption();
    }
}
