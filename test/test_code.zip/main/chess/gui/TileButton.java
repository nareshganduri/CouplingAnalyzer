package chess.gui;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import chess.game.Game;
import chess.game.layout.Spot;
import chess.game.pieces.Piece;
import chess.game.ui.Player;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

/**
 * A subclass of JavaFX Button with added functionality to make handling tiles
 * on the chess board easier
 * 
 * @author Naresh Ganduri
 *
 */
public class TileButton extends Button {
    /**
     * The TileButton uses images of size 64x64 (in pixels). They are set as
     * constants here to make it easier to change
     */
    private static final double TILE_WIDTH = 64;
    private static final double TILE_HEIGHT = 64;
    private int xPos;
    private int yPos;
    private ImageView tileGraphic;

    private boolean isSelected;
    private boolean isPossibleMove;

    /**
     * Constructs an interactive tile object at a given x and y coordinate on the
     * game board
     * 
     * @param xPos
     *            the x coordinate of the tile
     * @param yPos
     *            the y coordinate of the tile
     */
    public TileButton(int xPos, int yPos) {
        super();

        this.xPos = xPos;
        this.yPos = yPos;

        tileGraphic = new ImageView();
        this.setImage();

        this.setBGColor();

        this.registerEventHandlers();
    }

    /**
     * Generates the event handlers for this TileButton
     */
    private void registerEventHandlers() {
        this.setOnMouseEntered(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                handleMouseEnter();
            }
        });

        this.setOnMouseExited(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                handleMouseExit();
            }
        });

        this.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                handleClick();
            }
        });
    }

    /**
     * Gets the Spot object corresponding to this TileButton
     * 
     * @return the corresponding Spot object
     */
    public Spot getCorrespondingSpot() {
        return Game.getBoard().getSpot(xPos, yPos);
    }

    /**
     * Sets the image based on whichever chess piece happens to be sitting on this
     * tile
     */
    public void setImage() {
        Spot correspondingSpot = this.getCorrespondingSpot();
        String filename = correspondingSpot.getImageFilename();
        Image image = new Image(filename, TILE_WIDTH, TILE_HEIGHT, false, false);
        tileGraphic.setImage(image);
        this.setGraphic(tileGraphic);
    }

    /**
     * Sets the tile background color to get a checker board effect
     */
    void setBGColor() {
        if ((this.xPos + this.yPos) % 2 == 0) {
            this.setStyle("-fx-base: #555555;"); // set to black
        } else {
            this.setStyle("-fx-base: #dddddd;"); // set to white
        }
    }

    /**
     * Computes whether the player can move the piece at this TileButton
     * 
     * @return whether the piece at this tile can be moved
     */
    private boolean isMovable() {
        Piece occupant = this.getCorrespondingSpot().getOccupant();
        if (occupant != null) {
            Player occupantPlayer = occupant.getOwner();
            Player playerToMove = Game.getPlayerToMove();
            int moveSize = occupant.computeValidMoves().size();
            if (occupantPlayer == playerToMove && moveSize > 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Handle setting the highlight
     */
    public void setHighlight() {
        this.setStyle("-fx-base: #11ff11;"); // set to green
    }

    /**
     * Handle the user moving the mouse over the button;
     */
    private void handleMouseEnter() {
        if (this.isMovable() && Game.selectedPiece == null) {
            this.setHighlight();
        }
    }

    /**
     * Handle the user moving the mouse off of the button
     */
    private void handleMouseExit() {
        if (this.isSelected == false && this.isPossibleMove == false) {
            this.setBGColor();
        }
    }

    /**
     * Handle the user clicking the button
     */
    private void handleClick() {
        if (isPossibleMove == true) {
            BoardGUIManager.handleMove(this);
        } else if (isSelected) {
            // deselect the tile - the player wants to move something else
            isSelected = false;
            this.setBGColor();
            BoardGUIManager.resetBGColor();
        } else {
            if (this.isMovable() && BoardGUIManager.selectedTile == null) {
                isSelected = true;
                this.setStyle("-fx-base: #ff1111;"); // set to red
                BoardGUIManager.highlightPossibles(this);
            }
        }
    }

    /**
     * Sets whether this tile a possible place the player can move to
     * 
     * @param isPossibleMove
     *            whether this tile is a possible place the player can move to
     */
    public void setIsPossibleMove(boolean isPossibleMove) {
        this.isPossibleMove = isPossibleMove;
    }

    /**
     * Sets whether this TileButton has been selected - i.e. the player to move
     * wants to move the piece sitting on it
     * 
     * @param isSelected
     *            whether the tile is selected
     */
    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }
}
