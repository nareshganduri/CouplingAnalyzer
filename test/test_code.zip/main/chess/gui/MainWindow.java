package chess.gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * The MainWindow class handles the GUI components of the chess game
 * 
 * @author Naresh Ganduri
 *
 */
public class MainWindow extends Application {
    private static int WINDOW_WIDTH = 640;
    private static int WINDOW_HEIGHT = 640;
    
    private static Stage mainStage;
    
    /**
     * Keep track of player scores
     */
    private static ScoreManager scoreManager;

    /**
     * Starts the chess application up
     * 
     * @param args
     *            Console arguments
     */
    public static void main(String[] args) {
        // launch the GUI
        launch(args);
    }

    @Override
    public void start(Stage mainStage) throws Exception {
        MainWindow.mainStage = mainStage;
        BoardGUIManager.startNewGame();
        
        scoreManager = new ScoreManager();
    }

    /**
     * Initializes the main application window and sets its size and title
     * 
     * @param mainPane
     *            the BorderPane used for the scene
     * @param mainStage
     *            the stage for the application
     */
    public static void initializeWindow(BorderPane mainPane) {
        Scene scene = new Scene(mainPane, WINDOW_WIDTH, WINDOW_HEIGHT);
        mainStage.setTitle("Chess Game");
        mainStage.setScene(scene);
        mainStage.show();
    }
    
    /**
     * Returns the ScoreManager object being used by the game to keep track of the
     * game scores
     * 
     * @return the ScoreManager object keeping track of scores
     */
    public static ScoreManager getScoreManager() {
        return scoreManager;
    }
}
