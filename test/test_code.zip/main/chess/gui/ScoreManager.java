package chess.gui;

import chess.game.Game;

public class ScoreManager {
    /**
     * Keep track of player scores
     */
    private int whiteScore;
    private int blackScore;

    /**
     * Constructs a new ScoreManager and initializes the score to zero
     */
    public ScoreManager() {
        this.whiteScore = 0;
        this.blackScore = 0;
    }

    /**
     * Returns the White player's current score
     * 
     * @return the White player's current score
     */
    public int getWhiteScore() {
        return this.whiteScore;
    }

    /**
     * Returns the Black player's current score
     * 
     * @return the Black player's current score
     */
    public int getBlackScore() {
        return this.blackScore;
    }

    /**
     * Updates the current scores after a win
     */
    public void updateScores() {
        if (Game.getPlayerToMove() == Game.getWhitePlayer()) {
            this.blackScore += 1;
        } else {
            this.whiteScore += 1;
        }
    }
}
