package chess.game;

import java.util.ArrayList;

import chess.game.layout.Board;
import chess.game.layout.Spot;
import chess.game.pieces.Pawn;
import chess.game.pieces.Piece;
import chess.game.ui.MoveItem;
import chess.game.ui.Player;

/**
 * The Game class handles the chess game at the highest level.
 * 
 * @author Naresh Ganduri
 *
 */
public class Game {
    private static Board board;
    private static Player[] players;

    private static ArrayList<MoveItem> moveStack;

    /**
     * Keep track of the player whose turn it is to move
     */
    static Player playerToMove = null;
    public static Piece selectedPiece = null;

    /**
     * The board width
     */
    public static final int BOARD_WIDTH = 8;

    /**
     * The board height
     */
    public static final int BOARD_HEIGHT = 8;

    private static boolean isUsingCustomPieces = false;

    /**
     * Kicks off the chess game. Initializes various data structures to manage the
     * chess game backend.
     */
    public static void initializeGame() {
        // initialize an 8x8 board
        board = new Board(BOARD_WIDTH, BOARD_HEIGHT);

        // initialize the players
        players = new Player[2];
        players[0] = new Player(Player.Color.WHITE);
        players[1] = new Player(Player.Color.BLACK);
        players[0].setOpponent(players[1]);
        players[1].setOpponent(players[0]);

        playerToMove = getWhitePlayer();

        moveStack = new ArrayList<>();
    }

    /**
     * Returns the white player of this Game
     * 
     * @return the white Player object
     */
    public static Player getWhitePlayer() {
        return players[0];
    }

    /**
     * Sets the white player of this game
     * 
     * @param whitePlayer
     *            the Player object to set the white player to
     */
    public static void setWhitePlayer(Player whitePlayer) {
        players[0] = whitePlayer;
    }

    /**
     * Returns the black player of this Game
     * 
     * @return the black Player object
     */
    public static Player getBlackPlayer() {
        return players[1];
    }

    /**
     * Sets the black player of this game
     * 
     * @param blackPlayer
     *            the Player object to set the black player to
     */
    public static void setBlackPlayer(Player blackPlayer) {
        players[1] = blackPlayer;
    }

    /**
     * Returns the game board
     * 
     * @return The game board
     */
    public static Board getBoard() {
        return board;
    }

    /**
     * Sets the game board
     * 
     * @param newBoard
     *            the Board object to set this game's board to
     */
    public static void setBoard(Board newBoard) {
        board = newBoard;
    }

    /**
     * Returns an array of length 2 containing the Player objects used in this game.
     * The white player is stored in index 0, and the black player is stored in
     * index 1.
     * 
     * @return an array of Player objects
     */
    public static Player[] getPlayers() {
        return players;
    }

    /**
     * Sets the players of this game all at once using an array of Player objects.
     * 
     * @param newPlayers
     *            the array of players
     */
    public static void setPlayers(Player[] newPlayers) {
        players = newPlayers;
    }

    /**
     * Changes the current player to the next player
     */
    public static void nextPlayer() {
        if (playerToMove == Game.getWhitePlayer()) {
            playerToMove = Game.getBlackPlayer();
        } else {
            playerToMove = Game.getWhitePlayer();
        }
    }

    /**
     * Returns the player to move
     * 
     * @return the player to move
     */
    public static Player getPlayerToMove() {
        return playerToMove;
    }

    /**
     * Returns the stack of moves used in this game
     * 
     * @return an ArrayList of all moves used in this game
     */
    public static ArrayList<MoveItem> getMoveStack() {
        return moveStack;
    }

    /**
     * Sets the current player to move
     * 
     * @param playerToMove
     *            the current player to move
     */
    public static void setPlayerToMove(Player playerToMove) {
        Game.playerToMove = playerToMove;
    }

    /**
     * Undoes the last move on the move stack
     */
    public static void undoLastMove() {
        MoveItem lastMove = moveStack.remove(moveStack.size() - 1);

        Piece movedPiece = lastMove.getMovedPiece();
        Piece capturedPiece = lastMove.getCapturedPiece();
        Game.setPlayerToMove(lastMove.getPlayerToMove());
        movedPiece.moveToSpot(lastMove.getPrevSpot());
        if (lastMove.getResetFirstMove()) {
            ((Pawn) movedPiece).resetFirstMove();
        }
        if (capturedPiece != null) {
            capturedPiece.moveToSpot(lastMove.getNewSpot());
            capturedPiece.setCaptured(false);
        }
    }

    /**
     * Makes a new move to a destination spot
     * 
     * @param newSpot
     *            the destination spot for a piece
     */
    public static void makeNewMove(Spot newSpot) {
        Spot oldSpot = selectedPiece.getOccupyingSpot();
        Piece capturedPiece = newSpot.getOccupant();

        boolean resetFirstMove = false;
        if (selectedPiece instanceof Pawn) {
            resetFirstMove = ((Pawn) selectedPiece).isOnFirstMove();
        }

        MoveItem newMove = new MoveItem(playerToMove, selectedPiece, oldSpot, newSpot, capturedPiece, resetFirstMove);
        moveStack.add(newMove);

        selectedPiece.moveToSpot(newSpot);
        nextPlayer();
    }

    /**
     * Returns whether the game is using the custom pieces
     * 
     * @return whether the game is using the custom pieces
     */
    public static boolean getUsingCustomPieces() {
        return isUsingCustomPieces;
    }

    /**
     * Sets whether the game is using the custom pieces
     * 
     * @param isUsingCustomPieces
     *            whether the game is using the custom pieces
     */
    public static void setIsUsingCustomPieces(boolean isUsingCustomPieces) {
        Game.isUsingCustomPieces = isUsingCustomPieces;
    }
}
