package chess.game.utils;

import java.util.ArrayList;

import chess.game.layout.Move;

/**
 * The MoveList class is a simple wrapper class around the ArrayList class
 * designed specifically to handle storing Move objects and manipulating them.
 * 
 * @author Naresh Ganduri
 *
 */
public class MoveList extends ArrayList<Move> {

    /**
     * ArrayList requires a serial version UID
     */
    private static final long serialVersionUID = 1L;

    /**
     * Construct a copy MoveList from a given one.
     * 
     * NOTE: the references to each Move object in the list are preserved
     * 
     * @param moves
     *            the MoveList to copy
     */
    public MoveList(MoveList moves) {
        for (int i = 0; i < moves.size(); i++) {
            Move currMove = moves.get(i);
            this.add(currMove);
        }
    }

    /**
     * Default constructor - does nothing except call super()
     */
    public MoveList() {
        super();
    }

    /**
     * Returns whether this MoveList contains the given move.
     * 
     * @param move
     *            the move to check
     * @return whether the MoveList contains the given move
     */
    public boolean contains(Move move) {
        for (int i = 0; i < this.size(); i++) {
            Move currMove = this.get(i);
            if (currMove.equals(move)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Removes the given move from the MoveList. If the requested Move is not in the
     * MoveList, it does nothing.
     * 
     * @param move
     *            the Move object to remove
     */
    public void remove(Move move) {
        for (int i = 0; i < this.size(); i++) {
            Move currMove = this.get(i);
            if (currMove.equals(move)) {
                this.remove(i);
            }
        }
    }

}
