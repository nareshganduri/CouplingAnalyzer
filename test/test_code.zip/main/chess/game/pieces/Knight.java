package chess.game.pieces;

import chess.game.layout.Move;
import chess.game.utils.MoveList;

/**
 * The Knight class implements functionality specific to the Knight chess piece,
 * like its unique move set
 * 
 * @author Naresh Ganduri
 *
 */
public class Knight extends DoubledPiece {
    // the left and right initial x positions of the knight on the board
    private static final int LEFT_XPOS = 1;
    private static final int RIGHT_XPOS = 6;

    /**
     * Constructs a Knight object on a given side of the board
     * 
     * @param side
     *            which side of the board (left or right) this knight will start on
     */
    public Knight(Side side) {
        super(side, LEFT_XPOS, RIGHT_XPOS);

        // add moves
        this.moves.add(new Move(2, 1));
        this.moves.add(new Move(-2, 1));
        this.moves.add(new Move(2, -1));
        this.moves.add(new Move(-2, -1));
        this.moves.add(new Move(1, 2));
        this.moves.add(new Move(1, -2));
        this.moves.add(new Move(-1, 2));
        this.moves.add(new Move(-1, -2));

        // attack set
        this.attacks = new MoveList(this.moves);
    }

    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "knight.png";
    }
}
