package chess.game.pieces;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * A simple wrapper class around DoubledPiece used by the Player classes for
 * convenience. It offers getter methods to conveniently get the left or right
 * piece in a doubled pair
 * 
 * @author Naresh Ganduri
 *
 * @param <T>
 *            the Piece type that will be paired up.
 */
public class PiecePair<T extends DoubledPiece> {
    private T leftPiece;
    private T rightPiece;

    /**
     * Constructs a PiecePair object for a given Piece type
     * 
     * @param pieceClass
     *            the Class of the Piece that should exist in a pair
     */
    public PiecePair(Class<T> pieceClass) {
        try {
            Constructor<T> pieceConstructor = pieceClass.getConstructor(DoubledPiece.Side.class);

            this.leftPiece = pieceConstructor.newInstance(DoubledPiece.Side.LEFT);
            this.rightPiece = pieceConstructor.newInstance(DoubledPiece.Side.RIGHT);

        } catch (InstantiationException ignore) {

        } catch (IllegalAccessException ignore) {

        } catch (IllegalArgumentException ignore) {

        } catch (InvocationTargetException ignore) {

        } catch (NoSuchMethodException ignore) {

        } catch (SecurityException ignore) {

        }
    }

    /**
     * Returns the Piece object in this PiecePair that starts on the left side of
     * the game board
     * 
     * @return the left Piece object
     */
    public T getLeftPiece() {
        return leftPiece;
    }

    /**
     * Returns the Piece object in this PiecePair that starts on the right side of
     * the game board
     * 
     * @return the right Piece object
     */
    public T getRightPiece() {
        return rightPiece;
    }
}
