package chess.game.pieces;

import chess.game.utils.MoveList;

/**
 * The Wazir class implements functionality for a custom chess piece that
 * moves horizontally or vertically by at most 1 space
 * 
 * @author Naresh Ganduri
 *
 */
public class Wazir extends DoubledPiece {
    private static final int LEFT_XPOS = 0;
    private static final int RIGHT_XPOS = 7;
    
    
    
    /**
     * Construct a CustomPiece2 object
     */
    public Wazir(Side side) {
        super(side, LEFT_XPOS, RIGHT_XPOS);

        // create the custom moves
        PieceInitializer pieceInitializer = new PieceInitializer();
        pieceInitializer.addHorizontalVerticalMoves(this, 2);

        // we clone the moves list to make the attacks list
        this.attacks = new MoveList(this.moves);
        
        yPos = 2;
    }
    
    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "wazir.png";
    }
}
