package chess.game.pieces;

import chess.game.Game;
import chess.game.layout.Move;
import chess.game.layout.Spot;
import chess.game.utils.MoveList;

/**
 * This class implements functionality specific to the Pawn chess piece, like
 * its specific move and attack set, and also handling the unique move where it
 * moves up two spots on its very first move.
 * 
 * @author Naresh Ganduri
 *
 */
public class Pawn extends Piece {
    private boolean isOnFirstMove = true;
    private int pawnCount;

    /**
     * Initializes a new pawn piece - assigns it to a player, and gives it a
     * starting position on the game board
     * 
     * @param xPos
     *            the x position on this board where the pawn is initially placed
     */
    public Pawn(int xPos) {
        super();

        // initialize the pawn's move set
        this.moves.add(new Move(0, 2));
        this.moves.add(new Move(0, 1));

        // initialize the pawn's set of attack moves
        this.attacks = new MoveList();
        this.attacks.add(new Move(-1, 1));
        this.attacks.add(new Move(1, 1));

        this.pawnCount = xPos;
    }

    /**
     * Flips the pawn's moves over the y-axis, which is necessary if playing as the
     * black player, as moves are calculated in global coordinates.
     */
    private void flipMovesOverYAxis() {
        for (int i = 0; i < this.moves.size(); i++) {
            Move currMove = this.moves.get(i);
            currMove.setYOffset(currMove.getYOffset() * -1);
        }
        for (int i = 0; i < this.attacks.size(); i++) {
            Move currMove = this.attacks.get(i);
            currMove.setYOffset(currMove.getYOffset() * -1);
        }
    }

    @Override
    public void setInitialPosition() {
        int xPos = this.pawnCount;
        int yPos = 1;
        if (this.getOwner().isBlack()) {
            xPos = Game.BOARD_WIDTH - 1 - this.pawnCount;
            yPos = Game.BOARD_HEIGHT - 2;

            this.flipMovesOverYAxis();
        }

        Spot occupyingSpot = Game.getBoard().getSpot(xPos, yPos);
        Game.getBoard().movePieceToSpot(this, occupyingSpot);
    }

    /**
     * Returns whether this Pawn has made its first move
     * 
     * @return whether the pawn has made its first move
     */
    public boolean isOnFirstMove() {
        return isOnFirstMove;
    }

    /**
     * Sets whether this Pawn has made its first move
     * 
     * @param isOnFirstMove
     *            whether the pawn has made its first move
     */
    public void setOnFirstMove(boolean isOnFirstMove) {
        this.isOnFirstMove = isOnFirstMove;
    }

    @Override
    public void moveToSpot(Spot spot) {
        super.moveToSpot(spot);

        // don't allow moving by two after the first move
        if (isOnFirstMove()) {
            setOnFirstMove(false);

            this.moves.remove(new Move(0, 2));
            this.moves.remove(new Move(0, -2));
        }
    }

    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "pawn.png";
    }

    public void resetFirstMove() {
        this.isOnFirstMove = true;
        if (this.getOwner() == Game.getBlackPlayer()) {
            this.moves.add(new Move(0, -2));
        } else {
            this.moves.add(new Move(0, 2));
        }
    }
}
