package chess.game.pieces;

import chess.game.Game;
import chess.game.utils.MoveList;

/**
 * The Rook class implements functionality unique to rooks
 * 
 * @author Naresh Ganduri
 *
 */
public class Rook extends DoubledPiece {
    private static final int LEFT_XPOS = 0;
    private static final int RIGHT_XPOS = 7;

    /**
     * Constructs a Rook object on a given side of the board
     * 
     * @param side
     *            which side of the board (left or right) this rook will start on
     */
    public Rook(Side side) {
        super(side, LEFT_XPOS, RIGHT_XPOS);

        PieceInitializer pieceInitializer = new PieceInitializer();
        pieceInitializer.addHorizontalVerticalMoves(this, Game.BOARD_HEIGHT);

        // attack set
        this.attacks = new MoveList(this.moves);
    }

    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "rook.png";
    }
}
