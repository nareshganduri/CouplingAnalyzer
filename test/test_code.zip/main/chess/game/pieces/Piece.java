package chess.game.pieces;

import java.util.ArrayList;

import chess.game.Game;
import chess.game.layout.Move;
import chess.game.layout.OutOfBoundsException;
import chess.game.layout.Spot;
import chess.game.ui.Player;
import chess.game.utils.MoveList;

/**
 * The base class all pieces derive from. Common functionality is implemented
 * here.
 * 
 * @author Naresh Ganduri
 *
 */
public class Piece {
    private Player owner;

    /**
     * The MoveList of regular moves this Piece can make. Here, 'regular' means any
     * valid move the piece can make without capturing another piece
     */
    protected MoveList moves;

    /**
     * The MoveList of attack moves this Piece can make. Here, 'attack moves' means
     * any move the piece can make that involves capturing another piece
     */
    protected MoveList attacks;
    private Spot occupyingSpot;

    private boolean isCaptured;

    /**
     * Constructs a new Piece object
     */
    public Piece() {
        this.isCaptured = false;
        this.moves = new MoveList();
    }

    /**
     * Returns the Player object that owns this piece
     * 
     * @return a Player object that owns this piece
     */
    public Player getOwner() {
        return owner;
    }

    /**
     * Sets which Player object owns this piece
     * 
     * @param owner
     *            the Player object this piece will belong to
     */
    public void setOwner(Player owner) {
        this.owner = owner;
    }

    /**
     * Computes a valid set of moves as a subset of a given move set or attack set
     * 
     * @param moveSet
     *            the set of moves to filter for valid moves
     * @param isAttackSet
     *            whether the move set is a set of attacks
     * @return a set of valid moves or attacks
     */
    private MoveList computeValidMovesFromMoveSet(MoveList moveSet, boolean isAttackSet) {
        MoveList validMoves = new MoveList();

        // iterate through all the regular moves and keep only the valid ones
        for (int i = 0; i < moveSet.size(); i++) {
            Move currMove = moveSet.get(i);

            // check if this move would move this piece off the game board
            Spot resultSpot;
            try {
                resultSpot = this.occupyingSpot.addMove(currMove);

                /*
                 * Check if the result spot is occupied already. If it is, there are two
                 * possibilities: (1) The occupying piece belongs to this player, so this piece
                 * cannot move there. (2) The occupying piece belongs to the opposing piece, so
                 * this piece can move there and capture it, assuming the attack set is valid.
                 * 
                 * If it is occupied, then the piece can only move there if it is attacking.
                 */
                if (resultSpot.getOccupant() != null) {
                    if (isAttackSet) {
                        if (resultSpot.getOccupant().owner == this.owner) {
                            continue;
                        }
                    } else {
                        continue;
                    }
                } else {
                    if (isAttackSet) {
                        continue;
                    }
                }
            } catch (OutOfBoundsException e) {
                continue;
            }

            /*
             * the move is not valid if there is no clear path to the destination spot -
             * i.e. there are no pieces in the path between the current spot and the
             * destination
             */
            if (this.isBlockedBy(currMove)) {
                continue;
            }

            // valid move, so save it
            validMoves.add(currMove);
        }

        return validMoves;
    }

    /**
     * Computes all the valid moves a given piece can make
     * 
     * @return A list of valid moves
     */
    public MoveList computeValidMoves() {
        if (this.isCaptured) {
            return new MoveList();
        }
        ArrayList<Move> validRegularMoves = this.computeValidMovesFromMoveSet(this.moves, false);
        ArrayList<Move> validAttackMoves = this.computeValidMovesFromMoveSet(this.attacks, true);

        ArrayList<Move> validMoves = new ArrayList<>();
        validMoves.addAll(validRegularMoves);
        validMoves.addAll(validAttackMoves);

        return this.filterCheckMoves(validMoves);
    }

    /**
     * Filters an ArrayList of otherwise valid moves to get rid of any moves that
     * would place one's self in check
     * 
     * @param validMoves
     *            the ArrayList of otherwise valid moves to filter
     * @return A filtered set of valid moves that will not put the king in check
     */
    private MoveList filterCheckMoves(ArrayList<Move> validMoves) {
        MoveList noCheckMoves = new MoveList();

        for (int i = 0; i < validMoves.size(); i++) {
            boolean willSelfCheck = false; // a flag

            Move currMove = validMoves.get(i);
            try {
                Spot prevSpot = this.occupyingSpot;
                Spot endSpot = prevSpot.addMove(currMove);
                Piece prevOccupant = endSpot.getOccupant();

                this.occupyingSpot = endSpot;
                endSpot.setOccupant(this);
                prevSpot.setOccupant(null);

                if (prevOccupant != null) {
                    prevOccupant.setCaptured(true);
                    prevOccupant.setOccupyingSpot(null);
                }

                if (this.owner.getKing().isInCheck()) {
                    willSelfCheck = true;
                }

                if (prevOccupant != null) {
                    prevOccupant.setCaptured(false);
                    prevOccupant.setOccupyingSpot(endSpot);
                }

                prevSpot.setOccupant(this);
                this.occupyingSpot = prevSpot;
                endSpot.setOccupant(prevOccupant);
            } catch (OutOfBoundsException ignore) {
                // ignore
            }

            if (willSelfCheck == false) {
                noCheckMoves.add(currMove);
            }
        }

        return noCheckMoves;
    }

    /**
     * Return whether the piece is blocked from making a potential move by another
     * piece
     * 
     * @param move
     *            the move to check the path to
     * @return whether this piece is blocked from making the given move
     */
    private boolean isBlockedBy(Move move) {
        if (move.isHorizontal() || move.isVertical() || move.isDiagonal()) {
            Move moveDir = this.computeMoveDirection(move);
            try {
                Spot currSpotCheck = this.occupyingSpot.addMove(moveDir);
                Spot endSpotCheck = this.occupyingSpot.addMove(move);

                // push forward in the move direction until we hit the end move
                while (currSpotCheck.equals(endSpotCheck) == false) {
                    if (currSpotCheck.getOccupant() != null) {
                        return true;
                    } else {
                        currSpotCheck = currSpotCheck.addMove(moveDir);
                    }
                }
            } catch (OutOfBoundsException ignore) {
                // ignore because this can never happen
            }
            return false;
        } else {
            // only knights can move in ways that are neither
            // horizontal, vertical, nor diagonal, and they can't
            // be blocked by other pieces
            return false;
        }
    }

    /**
     * Computes the direction that a move is in, given that it is horizontal,
     * vertical, or diagonal
     * 
     * @param move
     *            The move to 'normalize'
     * @return a Move that moves the piece by exactly one square either
     *         horizontally, vertically, or diagonal
     */
    private Move computeMoveDirection(Move move) {
        Move moveDirection;
        if (move.isHorizontal()) {
            if (move.getXOffset() < 0) {
                moveDirection = new Move(-1, 0);
            } else {
                moveDirection = new Move(1, 0);
            }
        } else if (move.isVertical()) {
            if (move.getYOffset() < 0) {
                moveDirection = new Move(0, -1);
            } else {
                moveDirection = new Move(0, 1);
            }
        } else {
            // move is guaranteed to be diagonal
            if (move.getXOffset() < 0) {
                if (move.getYOffset() < 0) {
                    moveDirection = new Move(-1, -1);
                } else {
                    moveDirection = new Move(-1, 1);
                }
            } else {
                if (move.getYOffset() < 0) {
                    moveDirection = new Move(1, -1);
                } else {
                    moveDirection = new Move(1, 1);
                }
            }
        }

        return moveDirection;
    }

    /**
     * Returns whether this piece is currently attacking a given piece
     * 
     * @param piece
     *            The piece to check if it is being attacked
     * @return Whether this piece is attacking the given piece
     */
    public boolean isAttacking(Piece piece) {
        MoveList validAttackMoves = this.computeValidMovesFromMoveSet(attacks, true);
        for (int i = 0; i < validAttackMoves.size(); i++) {
            Move currAttack = validAttackMoves.get(i);
            try {
                Spot endSpot = this.occupyingSpot.addMove(currAttack);
                if (endSpot.getOccupant() == piece) {
                    return true;
                }
            } catch (OutOfBoundsException e) {
                continue;
            }
        }
        return false;
    }

    /**
     * Changes the occupying spot of this piece
     * 
     * @param spot
     *            the new occupying spot
     */
    public void setOccupyingSpot(Spot spot) {
        this.occupyingSpot = spot;
    }

    /**
     * Sets the initial position of a piece on the board with respect to global
     * coordinates
     */
    public void setInitialPosition() {

    }

    /**
     * Moves the piece to the given spot
     * 
     * @param spot
     *            The spot to move to
     */
    public void moveToSpot(Spot spot) {
        this.occupyingSpot.setOccupant(null);
        this.occupyingSpot = null;
        Game.getBoard().movePieceToSpot(this, spot);
    }

    /**
     * Return the spot this piece is occupying
     * 
     * @return the occupying spot
     */
    public Spot getOccupyingSpot() {
        return this.occupyingSpot;
    }

    /**
     * Return the move set of this piece
     * 
     * @return the move set
     */
    public MoveList getMoves() {
        return moves;
    }

    /**
     * Set the move set of this piece
     * 
     * @param moves
     *            the move set to change to
     */
    public void setMoves(MoveList moves) {
        this.moves = moves;
    }

    /**
     * Returns a String corresponding to the filename of the image to use on a given
     * GUI tile
     * 
     * @return the filename
     */
    public String getImageFilename() {
        if (this.owner.isBlack()) {
            return "black/";
        } else {
            return "white/";
        }
    }

    /**
     * Returns whether the piece has been captured
     * 
     * @return whether the piece has been captured
     */
    public boolean getCaptured() {
        return this.isCaptured;
    }

    /**
     * Sets whether the piece was captured
     * 
     * @param isCaptured
     *            whether the piece was captured
     */
    public void setCaptured(boolean isCaptured) {
        this.isCaptured = isCaptured;
    }
}
