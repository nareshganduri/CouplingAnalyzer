package chess.game.pieces;

import chess.game.layout.Move;

/**
 * The PieceInitializer class contains several helper methods for initializing
 * common move sets across various chess piece types
 * 
 * @author Naresh Ganduri
 *
 */
public class PieceInitializer {

    /**
     * Adds horizontal and vertical moves to a piece
     * 
     * @param piece
     *            the Piece object to add the moves to
     * @param maxDist
     *            the maximum number of squares that can be moved in one direction
     */
    public void addHorizontalVerticalMoves(Piece piece, int maxDist) {
        for (int i = 1; i < maxDist; i++) {
            piece.moves.add(new Move(0, i));
            piece.moves.add(new Move(0, -i));
            piece.moves.add(new Move(i, 0));
            piece.moves.add(new Move(-i, 0));
        }
    }

    /**
     * Adds diagonal moves to a piece
     * 
     * @param piece
     *            the Piece object to add the moves to
     * @param maxDist
     *            the maximum number of squares that can be moved in one direction
     */
    void addDiagonalMoves(Piece piece, int maxDist) {
        for (int i = 1; i < maxDist; i++) {
            piece.moves.add(new Move(i, i));
            piece.moves.add(new Move(i, -i));
            piece.moves.add(new Move(-i, i));
            piece.moves.add(new Move(-i, -i));
        }
    }

}
