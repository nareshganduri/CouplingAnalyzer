package chess.game.pieces;

import chess.game.Game;
import chess.game.layout.Spot;

/**
 * The base class that all doubled pieces (e.g. Knight, Bishop, Rook) derive
 * from
 * 
 * @author Naresh Ganduri
 *
 */
public class DoubledPiece extends Piece {
    public enum Side {
        LEFT, RIGHT
    }

    private int leftXPos;
    private int rightXPos;
    protected int yPos = 0;
    
    Side side;

    /**
     * Initializes a piece that is 'doubled' - i.e. appears on both sides of the
     * board for a single player
     * 
     * @param side
     *            whether this piece is the left or right one of the pair
     * @param leftXPos
     *            the x position of the left piece
     * @param rightXPos
     *            the x position of the right piece
     */
    DoubledPiece(Side side, int leftXPos, int rightXPos) {
        super();
        this.side = side;
        this.leftXPos = leftXPos;
        this.rightXPos = rightXPos;
    }

    @Override
    public void setInitialPosition() {
        int initialLeftXPos = this.leftXPos;
        int initialRightXPos = this.rightXPos;
        
        if (this.getOwner().isBlack()) {
            initialLeftXPos = Game.BOARD_WIDTH - 1 - this.leftXPos;
            initialRightXPos = Game.BOARD_WIDTH - 1 - this.rightXPos;
            yPos = Game.BOARD_HEIGHT - 1 - yPos;
        }

        Spot occupyingSpot;
        if (this.side == Side.LEFT) {
            occupyingSpot = Game.getBoard().getSpot(initialLeftXPos, yPos);
        } else {
            occupyingSpot = Game.getBoard().getSpot(initialRightXPos, yPos);
        }
        Game.getBoard().movePieceToSpot(this, occupyingSpot);
    }
}
