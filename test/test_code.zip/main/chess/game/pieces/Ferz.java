package chess.game.pieces;

import chess.game.utils.MoveList;

/**
 * The Ferz class implements functionality for a custom chess piece that
 * can move diagonally by one square in any direction
 * 
 * @author Naresh Ganduri
 *
 */
public class Ferz extends DoubledPiece {
    private static final int LEFT_XPOS = 1;
    private static final int RIGHT_XPOS = 6;
    
    /**
     * Construct a CustomPiece1 object
     */
    public Ferz(Side side) {
        super(side, LEFT_XPOS, RIGHT_XPOS);

        // create all the custom piece moves
        PieceInitializer pieceInitializer = new PieceInitializer();
        pieceInitializer.addDiagonalMoves(this, 2);

        // we clone the moves list to make the attacks list
        this.attacks = new MoveList(this.moves);
        
        yPos = 2;
    }
    
    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "ferz.png";
    }
}
