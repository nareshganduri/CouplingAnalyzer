package chess.game.pieces;

import chess.game.Game;
import chess.game.layout.Spot;
import chess.game.utils.MoveList;

/**
 * This class handles functionality unique to the Queen chess piece, like its
 * unique moves and attacks, and placing itself in the proper spot on the board
 * at startup.
 * 
 * @author Naresh Ganduri
 *
 */
public class Queen extends Piece {
    private static int X_POSITION = 3;

    /**
     * Constructs a Queen object
     */
    public Queen() {
        super();

        // initialize move set
        PieceInitializer pieceInitializer = new PieceInitializer();
        pieceInitializer.addDiagonalMoves(this, Game.BOARD_HEIGHT);
        pieceInitializer.addHorizontalVerticalMoves(this, Game.BOARD_HEIGHT);

        // attack set
        this.attacks = new MoveList(this.moves);
    }

    @Override
    public void setInitialPosition() {
        Spot occupyingSpot;
        if (this.getOwner().isBlack() == false) {
            occupyingSpot = Game.getBoard().getSpot(Queen.X_POSITION, 0);
        } else {
            occupyingSpot = Game.getBoard().getSpot(Queen.X_POSITION, Game.BOARD_HEIGHT - 1);
        }

        Game.getBoard().movePieceToSpot(this, occupyingSpot);
    }

    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "queen.png";
    }
}
