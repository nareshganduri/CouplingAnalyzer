package chess.game.pieces;

import chess.game.Game;
import chess.game.layout.Spot;
import chess.game.ui.Player;
import chess.game.utils.MoveList;

/**
 * This class implements functionality specific to the King chess piece, like
 * specifying its initial position on the board and checking whether the player
 * is in check or checkmate
 * 
 * @author NSG
 *
 */
public class King extends Piece {
    private static int X_POSITION = 4;

    /**
     * Constructs a King object
     */
    public King() {
        super();

        // create all the king moves
        PieceInitializer pieceInitializer = new PieceInitializer();
        pieceInitializer.addDiagonalMoves(this, 2);
        pieceInitializer.addHorizontalVerticalMoves(this, 2);

        // the king attacks in the same way it moves, so
        // we clone the moves list to make the attacks list
        this.attacks = new MoveList(this.moves);
    }

    @Override
    public void setInitialPosition() {
        Spot occupyingSpot;
        if (this.getOwner().isBlack() == false) {
            occupyingSpot = Game.getBoard().getSpot(King.X_POSITION, 0);
        } else {
            occupyingSpot = Game.getBoard().getSpot(King.X_POSITION, Game.BOARD_HEIGHT - 1);
        }

        Game.getBoard().movePieceToSpot(this, occupyingSpot);
    }

    /**
     * Returns whether this king is in check
     * 
     * @return whether this king is in check
     */
    public boolean isInCheck() {
        // get the opponent player
        Player opponent = this.getOwner().getOpponent();

        // check to see if any of the opponent's pieces are attacking
        // this king
        for (int i = 0; i < opponent.getPieces().size(); i++) {
            Piece currPiece = opponent.getPieces().get(i);
            if (currPiece.getCaptured()) {
                continue;
            }
            if (currPiece.isAttacking(this) == true) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns whether this king is in checkmate
     * 
     * @return whether this king is in checkmate
     */
    public boolean isInCheckmate() {
        // can not be checkmate if king is not in check
        if (this.isInCheck() == false) {
            return false;
        }

        // check to see if any of this player's pieces have valid moves
        // that won't leave this king in check
        boolean validMovesExist = false;
        Player owner = this.getOwner();
        for (int i = 0; i < owner.getPieces().size(); i++) {
            Piece currPiece = owner.getPieces().get(i);
            // must ignore pieces that are no longer on the board
            if (currPiece.getCaptured()) {
                continue;
            }
            if (currPiece.computeValidMoves().size() != 0) {
                validMovesExist = true;
            }
        }

        return !validMovesExist;
    }

    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "king.png";
    }
}
