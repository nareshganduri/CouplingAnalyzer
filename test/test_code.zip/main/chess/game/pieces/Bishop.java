package chess.game.pieces;

import chess.game.Game;
import chess.game.utils.MoveList;

/**
 * This class implements functionality specific to the Bishop chess piece.
 * 
 * @author Naresh Ganduri
 *
 */
public class Bishop extends DoubledPiece {
    private static final int LEFT_XPOS = 2;
    private static final int RIGHT_XPOS = 5;

    /**
     * Construct a Bishop object
     * 
     * @param side
     *            which side (left or right) of the board this bishop will begin on
     */
    public Bishop(Side side) {
        super(side, LEFT_XPOS, RIGHT_XPOS);

        // initialize the move set
        PieceInitializer pieceInitializer = new PieceInitializer();
        pieceInitializer.addDiagonalMoves(this, Game.BOARD_HEIGHT);

        // attack set
        this.attacks = new MoveList(this.moves);
    }

    @Override
    public String getImageFilename() {
        return super.getImageFilename() + "bishop.png";
    }
}
