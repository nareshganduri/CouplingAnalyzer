package chess.game.layout;

import chess.game.Game;
import chess.game.pieces.Piece;

/**
 * This class implements functionality related to getting and setting board
 * spots and also checking if the user requests a spot that does not exist on
 * the game board - i.e. it is out of bounds
 * 
 * @author Naresh Ganduri
 *
 */
public class Board {
    Spot[][] spots;

    /**
     * Constructs a game board as an array of Spot objects with user-specified
     * dimensions
     * 
     * @param sizeX
     *            the width of the board
     * @param sizeY
     *            the height of the board
     */
    public Board(int sizeX, int sizeY) {
        spots = new Spot[sizeX][sizeY];
        for (int i = 0; i < sizeX; i++) {
            for (int j = 0; j < sizeY; j++) {
                spots[i][j] = new Spot(i, j);
            }
        }
    }

    /**
     * Returns the Spot object located at a given x and y coordinate. NOTE:
     * getSpot() assumes that all inputs will be valid
     * 
     * @param xPos
     *            the x coordinate
     * @param yPos
     *            the y coordinate
     * @return the Spot object in the given position
     */
    public Spot getSpot(int xPos, int yPos) {
        return spots[xPos][yPos];
    }

    /**
     * Returns whether a spot index is out of bounds
     * 
     * @param xOffset
     *            the x value of the index into the board
     * @param yOffset
     *            the y value of the index into the board
     * @return whether the spot index is out of bounds
     */
    public boolean isOutOfBounds(int xOffset, int yOffset) {
        if (xOffset < 0 || xOffset >= Game.BOARD_WIDTH) {
            return true;
        }

        if (yOffset < 0 || yOffset >= Game.BOARD_HEIGHT) {
            return true;
        }

        return false;
    }

    /**
     * Moves a given piece to a given spot. It assumes the spot given will be a
     * valid spot
     * 
     * @param piece
     *            The piece to move
     * @param spot
     *            The spot to move the piece to
     */
    public void movePieceToSpot(Piece piece, Spot spot) {
        Piece oldOccupant = spot.getOccupant();
        if (oldOccupant != null) {
            oldOccupant.setCaptured(true);
        }
        piece.setOccupyingSpot(spot);
        spot.setOccupant(piece);
    }
}
