package chess.game.layout;

/**
 * The Move class handles several basic properties of a standard chess move. For
 * example, whether it is horizontal, vertical, diagonal, etc., or comparing two
 * separate Move objects to see if they both describe the same move.
 * 
 * @author Naresh Ganduri
 *
 */
public class Move {
    int xOffset;
    int yOffset;

    /**
     * Constructs a Move object with a given x direction and y direction, denoted by
     * the number of spaces the piece should move either horizontally or vertically.
     * 
     * Negative x offsets indicate moving left. Negative y offsets indicate moving
     * down the board.
     * 
     * @param xOffset
     *            the number of tiles to move horizontally
     * @param yOffset
     *            the number of tiles to move vertically
     */
    public Move(int xOffset, int yOffset) {
        this.xOffset = xOffset;
        this.yOffset = yOffset;
    }

    /**
     * Returns whether this move is horizontal
     * 
     * @return whether the move is horizontal
     */
    public boolean isHorizontal() {
        if (this.yOffset == 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns whether this move is vertical
     * 
     * @return whether the move is vertical
     */
    public boolean isVertical() {
        if (this.xOffset == 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Return whether this move is diagonal
     * 
     * @return whether this move is diagonal
     */
    public boolean isDiagonal() {
        if (this.isHorizontal() || this.isVertical()) {
            return false;
        }

        if (this.xOffset == this.yOffset) {
            return true;
        } else if (this.xOffset == -this.yOffset) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Compares two Move objects and returns if they are equal
     * 
     * @param comparatorMove
     *            the move to compare to
     * @return whether this Move equals the comparator
     */
    public boolean equals(Move comparatorMove) {
        return this.xOffset == comparatorMove.xOffset && this.yOffset == comparatorMove.yOffset;
    }

    /**
     * Returns the x distance of this Move object
     * 
     * @return the xOffset
     */
    public int getXOffset() {
        return this.xOffset;
    }

    /**
     * Returns the y distance of this Move object
     * 
     * @return the yOffset
     */
    public int getYOffset() {
        return this.yOffset;
    }

    /**
     * Sets the y distance of this Move object.
     * 
     * @param yOffset
     */
    public void setYOffset(int yOffset) {
        this.yOffset = yOffset;

    }
}
