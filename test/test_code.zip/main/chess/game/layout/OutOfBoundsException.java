package chess.game.layout;

/**
 * OutOfBoundsException is thrown when the user requests a Spot that does not
 * exist on the game board
 * 
 * @author Naresh Ganduri
 *
 */
public class OutOfBoundsException extends Exception {

    /**
     * Exception requires a serial version UID
     */
    private static final long serialVersionUID = 1L;

}
