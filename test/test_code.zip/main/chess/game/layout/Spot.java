package chess.game.layout;

import chess.game.Game;
import chess.game.pieces.Piece;

/**
 * This class manages the spots used by the game board. It keeps track of what
 * chess piece is occupying it. It can also compute which spot a piece would
 * move to if that piece was occupying this spot.
 * 
 * @author Naresh Ganduri
 *
 */
public class Spot {
    private Piece occupant;
    int xPos;
    int yPos;

    /**
     * Constructs a Spot object in the given position on the chess board
     * 
     * @param xPos
     *            the x coordinate of the Spot
     * @param yPos
     *            the y coordinate of the Spot
     */
    public Spot(int xPos, int yPos) {
        this.occupant = null;
        this.xPos = xPos;
        this.yPos = yPos;
    }

    /**
     * Returns the Piece object currently occupying this spot. If the spot is
     * currently empty, it returns null.
     * 
     * @return the Piece object occupying the current spot
     */
    public Piece getOccupant() {
        return this.occupant;
    }

    /**
     * Sets the Piece object that is currently occupying this spot.
     * 
     * @param occupant
     *            the Piece object to occupy the current spot
     */
    public void setOccupant(Piece occupant) {
        this.occupant = occupant;
    }

    /**
     * Returns the spot that a piece would be in if it started in this spot and made
     * the given move
     * 
     * @param currMove
     *            the move the piece wants to make
     * @return The result spot
     * @throws OutOfBoundsException
     */
    public Spot addMove(Move currMove) throws OutOfBoundsException {
        int xOffset = currMove.xOffset;
        int yOffset = currMove.yOffset;

        int newXPos = this.xPos + xOffset;
        int newYPos = this.yPos + yOffset;

        if (Game.getBoard().isOutOfBounds(newXPos, newYPos)) {
            throw new OutOfBoundsException();
        } else {
            Spot resultSpot = Game.getBoard().getSpot(newXPos, newYPos);
            return resultSpot;
        }
    }

    /**
     * Returns the filename of the image to use when rendering the GUI of the
     * TileButton corresponding to this given Spot
     * 
     * @return the filename as a String
     */
    public String getImageFilename() {
        /**
         * need to handle null checking, so the Spot class has a simple wrapper function
         * around the occupying Piece's getImageFilename function that accounts for null
         */
        if (this.occupant == null) {
            return "transparent-bg.png";
        } else {
            return this.occupant.getImageFilename();
        }
    }

    /**
     * Returns the x position of this spot
     * 
     * @return the x position of this spot
     */
    public int getXPos() {
        return this.xPos;
    }

    /**
     * Returns the y position of this spot
     * 
     * @return the y position of this spot
     */
    public int getYPos() {
        return this.yPos;
    }
}
