package chess.game.ui;

import java.util.ArrayList;

import chess.game.Game;
import chess.game.pieces.Bishop;
import chess.game.pieces.DoubledPiece;
import chess.game.pieces.Ferz;
import chess.game.pieces.King;
import chess.game.pieces.Knight;
import chess.game.pieces.Pawn;
import chess.game.pieces.Piece;
import chess.game.pieces.PiecePair;
import chess.game.pieces.Queen;
import chess.game.pieces.Rook;
import chess.game.pieces.Wazir;

/**
 * This class handles initializing the pieces belonging to a given player, and
 * setting up data structures used to conveniently keep track of the player's
 * pieces. It also tracks the player's color (white or black).
 * 
 * @author Naresh Ganduri
 *
 */
public class Player {
    private Player opponent;

    public enum Color {
        /**
         * The color used for white players
         */
        WHITE,

        /**
         * The color used for black players
         */
        BLACK
    }

    private Color playerColor;

    // the pieces
    private ArrayList<Pawn> pawns;
    private PiecePair<Rook> rooks;
    private PiecePair<Knight> knights;
    private PiecePair<Bishop> bishops;
    private King king;
    private Queen queen;
    
    // the custom pieces
    private PiecePair<Ferz> ferzes;
    private PiecePair<Wazir> wazirs;

    private ArrayList<Piece> pieces;

    /**
     * Constructs a Player object
     * 
     * @param playerColor
     *            which color (white or black) the player will be
     */
    public Player(Color playerColor) {
        this.playerColor = playerColor;
        this.pieces = new ArrayList<Piece>();

        // initialize the pawns
        setPawns(new ArrayList<>());
        for (int i = 0; i < Game.BOARD_WIDTH; i++) {
            Pawn newPawn = new Pawn(i);
            getPawns().add(newPawn);
            this.addPiece(newPawn);
        }

        // initialize the doubled pieces
        rooks = this.addPiecePair(Rook.class);
        knights = this.addPiecePair(Knight.class);
        bishops = this.addPiecePair(Bishop.class);

        // initialize the king and queen
        king = new King();
        this.addPiece(king);

        queen = new Queen();
        this.addPiece(queen);
        
        // initialize the custom pieces if using them
        if (Game.getUsingCustomPieces()) {
            ferzes = this.addPiecePair(Ferz.class);
            wazirs = this.addPiecePair(Wazir.class);
        }
    }

    /**
     * Returns this player's king
     * 
     * @return the King object belonging to this player
     */
    public King getKing() {
        return king;
    }

    /**
     * Return an ArrayList of all the pieces this player currently owns
     * 
     * @return the ArrayList of active pieces
     */
    public ArrayList<Piece> getPieces() {
        return this.pieces;
    }

    /**
     * Helper method to add a pair of pieces for this player
     * 
     * @param pieceClass
     *            Which type of piece should be added
     * @return A PiecePair containing the pair of pieces
     */
    private <T extends DoubledPiece> PiecePair<T> addPiecePair(Class<T> pieceClass) {
        PiecePair<T> newPiecePair = new PiecePair<>(pieceClass);
        this.addPiece(newPiecePair.getLeftPiece());
        this.addPiece(newPiecePair.getRightPiece());

        return newPiecePair;
    }

    /**
     * helper method to finish adding a piece for this player. Stores the piece in a
     * list of pieces belonging to the player, sets the piece's owner, and sets its
     * initial position
     * 
     * @param piece
     *            the piece to add
     */
    private void addPiece(Piece piece) {
        piece.setOwner(this);
        piece.setInitialPosition();
        pieces.add(piece);
    }

    /**
     * Sets the Player object this player will play against
     * 
     * @param opponent
     *            the opposing Player object
     */
    public void setOpponent(Player opponent) {
        this.opponent = opponent;
    }

    /**
     * Returns the Player object this player is playing against
     * 
     * @return the opposing Player object
     */
    public Player getOpponent() {
        return this.opponent;
    }

    /**
     * Returns a PiecePair consisting of this player's Rook objects
     * 
     * @return a PiecePair containing this player's left and right rooks
     */
    public PiecePair<Rook> getRooks() {
        return this.rooks;
    }

    /**
     * Returns a PiecePair consisting of this player's Knight objects
     * 
     * @return a PiecePair containing this player's left and right knights
     */
    public PiecePair<Knight> getKnights() {
        return this.knights;
    }

    /**
     * Returns a PiecePair consisting of this player's Bishop objects
     * 
     * @return a PiecePair containing this player's left and right bishops
     */
    public PiecePair<Bishop> getBishops() {
        return this.bishops;
    }

    /**
     * Returns an ArrayList consisting of this player's Pawn objects
     * 
     * @return an ArrayList containing this player's pawns
     */
    public ArrayList<Pawn> getPawns() {
        return pawns;
    }

    /**
     * Sets all the Pawn objects currently belonging to this Player at once
     * 
     * @param pawns
     *            an ArrayList of of Pawn objects that should belong to this player
     */
    public void setPawns(ArrayList<Pawn> pawns) {
        this.pawns = pawns;
    }

    /**
     * Returns whether this player is the black player
     * 
     * @return whether this player is the black player
     */
    public boolean isBlack() {
        return this.playerColor == Player.Color.BLACK;
    }

    /**
     * Sets all of the pieces that this player currently has at once
     * 
     * @param newPieces
     *            an ArrayList of pieces that should belong to this player
     */
    public void setPieces(ArrayList<Piece> newPieces) {
        this.pieces = newPieces;
    }

    /**
     * The Queen object belonging to this player
     * 
     * @return this player's queen
     */
    public Queen getQueen() {
        return this.queen;
    }
    
    /**
     * Returns a PiecePair consisting of this player's Wazir objects
     * 
     * @return a PiecePair containing this player's left and right wazirs
     */
    public PiecePair<Wazir> getWazirs() {
        return this.wazirs;
    }
    
    /**
     * Returns a PiecePair consisting of this player's Ferz objects
     * 
     * @return a PiecePair containing this player's left and right ferzes
     */
    public PiecePair<Ferz> getFerzes() {
        return this.ferzes;
    }
    
    /**
     * Returns a String saying who the current Player is
     * 
     * @return a String saying who the current Player is
     */
    public String getPlayerString() {
        String playerString;
        if (this.playerColor == Color.WHITE) {
            playerString = "White";
        } else {
            playerString = "Black";
        }

        return playerString;
    }
}
