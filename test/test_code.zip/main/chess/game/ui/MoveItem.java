package chess.game.ui;

import chess.game.layout.Spot;
import chess.game.pieces.Piece;

/**
 * The MoveItem class handles all the game state info needed to store a single
 * move on the game's move stack
 * 
 * @author Naresh Ganduri
 *
 */
public class MoveItem {
    private Player playerToMove;
    private Piece movedPiece;
    private Spot prevSpot;
    private Spot newSpot;
    private Piece capturedPiece;
    private boolean resetFirstMove;

    /**
     * Constructs a new MoveItem
     * 
     * @param playerToMove
     *            The player that does the next move
     * @param movedPiece
     *            The piece that was moved
     * @param prevSpot
     *            The moved piece's original spot
     * @param newSpot
     *            The moved piece's new spot
     * @param capturedPiece
     *            The piece - if any - that was captured by this move
     * @param resetFirstMove
     *            whether the moved piece needs to have its first move reset (if it
     *            happens to be a Pawn)
     */
    public MoveItem(Player playerToMove, Piece movedPiece, Spot prevSpot, Spot newSpot, Piece capturedPiece,
            boolean resetFirstMove) {
        this.playerToMove = playerToMove;
        this.movedPiece = movedPiece;
        this.prevSpot = prevSpot;
        this.newSpot = newSpot;
        this.capturedPiece = capturedPiece;
        this.resetFirstMove = resetFirstMove;
    }

    /**
     * Returns the player that moved for this MoveItem
     * 
     * @return the player that moved for this MoveItem
     */
    public Player getPlayerToMove() {
        return this.playerToMove;
    }

    /**
     * Returns the Piece that was moved
     * 
     * @return the Piece that was moved
     */
    public Piece getMovedPiece() {
        return this.movedPiece;
    }

    /**
     * Returns the old spot of the moved piece
     * 
     * @return the old spot of the moved piece
     */
    public Spot getPrevSpot() {
        return this.prevSpot;
    }

    /**
     * Returns the new spot of the moved piece
     * 
     * @return the new spot of the moved piece
     */
    public Spot getNewSpot() {
        return this.newSpot;
    }

    /**
     * Returns the piece that was captured in this MoveItem, if there was any
     * 
     * @return the piece that was captured in this MoveItem, if there was any
     */
    public Piece getCapturedPiece() {
        return this.capturedPiece;
    }

    /**
     * Returns whether the moved Piece needs its first move ability to be reset
     * 
     * @return whether the moved Piece needs its first move ability to be reset
     */
    public boolean getResetFirstMove() {
        return this.resetFirstMove;
    }
}
